<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'i4ruU81USEwLosZ17B7XmNLxEX7203jX8Vt8Q5Z43t0DfDpP8LhGd3qc0qDzx+wuh8SR8kM8be0Tf/pmDBk3ZA==');
define('SECURE_AUTH_KEY',  'Qeh4wygu6TMmsk06ClsfmPDlc/cZ97gW3jQhbDg/9oFrI6vldmeoBWd0J3oVa+lX7JezyS9JpaRx93EF9oudNw==');
define('LOGGED_IN_KEY',    'Skavnt35poMLq7Ra7SQ0B0+pEwpeXyiv2c38V5fyPgxYneZO/DbFzMiHkzcnM2kdKQqJ4gFUW2Z/luj6JnM04w==');
define('NONCE_KEY',        'KwujT1qRI8FdDJ6fNI8zOyZgNwS6IWQYsCZmzNEqKdayxH39ppWV7a6XtMgbLwuF0GU5MbAEMiHx3rHYD/i8FA==');
define('AUTH_SALT',        'urrD4yRFe1qkXfl+RiA2Au91ymfOKz85Wx+Dq6cz/5nyMSo0Ja6m8Z7Uo/ugvT5WdeOived9DihWo08/iTppVA==');
define('SECURE_AUTH_SALT', 'Iopee0t4mFSyEi2KUana/K7gzsCv83N4LOTVyPTO+InVMH4JH36UVNsWtsfz8R4EQdS0K4OxXqHScCJuv+wE5w==');
define('LOGGED_IN_SALT',   'vlv6Hidt47tUazyK3+THnEBQroWV4UzTaHHkpxzwm+1FYWVzy+dao+FqacdaHLos5YU2Q8M1OJC0aXApxhaPBw==');
define('NONCE_SALT',       'mB0Guu4D8ATamGyDlhi4zDw2SiZbK6C5KTFt4Y733P4vRzzE1xbjmxD5hl6tTeJujn61k7ovvuWAhj/639LW8A==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
